<div class="row mt-5 mb-3">
  <div class="col-sm-6">
      <h4>User Data</h4>
  </div>
  <div class="col-sm-6">
      <a class="btn btn-primary pull-right" href="<?php echo site_url('addNewUser');?>">Add New User</a>   
  </div>
</div>

<div class="table-responsive">
  <table class="table">
    <thead>
          <th>Name</th>
          <th>Country</th>
          <th>Email</th>
          <th>Mobile No</th>
    </thead>
    <tbody>
      <?php
         foreach($userData as $user) {
            echo '<tr><td>' . $user['name']. '</td><td>'.$user['country'].'</td><td>'.$user['email'].'</td><td>'.$user['mobileno'].'</td></tr>';
        }
      ?>
          
    </tbody>
  </table>
</div>

    