<div class="row mt-5 mb-3">
      <h4>Add New User</h4>
</div>
<form class="mt-8" action="<?php echo site_url('insertNewUser');?>" method="post">
  <div class="form-group row">
    <label for="username" class="col-sm-2 col-form-label">Name</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="username" data-validation="length alphanumeric" 
     data-validation-length="3-12" 
     data-validation-error-msg="User name has to be an alphanumeric value (3-12 char)" name="u_name" placeholder="Name">
      <span class="error"></span>
    </div>
  </div>
  <div class="form-group row">
    <label for="usercountry" class="col-sm-2 col-form-label">Country</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="usercountry" name="u_country" data-validation="country" placeholder="Country">
      <span class="error"></span>
    </div>
  </div>
  <div class="form-group row">
    <label for="staticEmail" class="col-sm-2 col-form-label">Email</label>
    <div class="col-sm-10">
      <input type="text"  class="form-control" data-validation="email" id="staticEmail" name="u_email" placeholder="email@example.com" >
    </div>
  </div>
  <div class="form-group row">
    <label for="birthdate" class="col-sm-2 col-form-label">Birth Date</label>
    <div class="col-sm-10">
      <input type="text"  class="form-control" placeholder="1990-12-23" data-validation="date" data-validation-format="yyyy-mm-dd" id="birthdate" name="u_birthdate">
    </div>
  </div>
  <div class="form-group row">
    <label for="usermobilenumber" class="col-sm-2 col-form-label">Mobile Number</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="usermobilenumber" data-validation="swephone" name="u_mobile" placeholder="Mobile Number">
      <span class="error"></span>
    </div>
  </div>
  <div class="form-group row">
    <label for="useraboutyou" class="col-sm-2 col-form-label">About You</label>
    <div class="col-sm-10">
      <textarea class="form-control" id="useraboutyou" name="u_about"></textarea>
      <span class="error"></span>
    </div>
  </div>
  <div class="form-group row">
    <div class="col-sm-12">
        <input type="submit" id="addUser" class="btn btn-primary pull-right" value="Add User" />
    </div>
  </div>
</form>

