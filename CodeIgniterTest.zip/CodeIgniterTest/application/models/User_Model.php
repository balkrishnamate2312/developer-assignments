<?php

class User_Model extends CI_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

    /**
	* Function to get user data in list
	* 
	* @return array
    */
    public function getAllUsers(){
    	$query = $this->db->get('userdata');

    	$result = $query->result_array();

    	return $result;
    }

    /** 
	* Function to insert data
	*
	* @param array $data information of user
	* @return void
    */
    
    function insertUser($data)
    {
    	$this->db->insert('userdata',$data);
        /*$query = $this->db->get('entries', 10);
        return $query->result();*/
    }

    

}


?>