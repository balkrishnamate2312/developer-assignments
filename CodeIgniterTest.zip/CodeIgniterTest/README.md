# developer-assignments
Code assignments for evaluating developers
