$(document).ready(function(){
	//alert('Hello');
	$('#addUser').on('click',function(e){
		var usermobile = $('#usermobilenumber').val();
		alert(userMobile);
		return false;
		var regexmobile = new RegExp("^\+?([0-9]{2})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{4})$");
		if(usermobile.match(regexmobile)) {
			
			alert('Match');
					} else {
			alert('Missmatch');
		}

	})

		
});
     $.validate({
    lang: 'en',
    modules : 'location, date, security, file',
    onModulesLoaded : function() {
      $('#usercountry').suggestCountry();
    }
  });

  // Restrict presentation length
  $('#presentation').restrictLength( $('#pres-max-length') );

